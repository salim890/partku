<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\ActivityLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    // 1. Halaman Checkout
    public function index()
    {
        $cart = session()->get('cart', []);
        if (empty($cart)) {
            return redirect()->route('cart.index')->with('success', 'Keranjang kosong. Silakan pilih produk dulu.');
        }
        return view('checkout');
    }

    // 2. Proses Checkout (Guest, Log, Diskon, Ongkir)
    public function process(Request $request)
    {
        $request->validate([
            'name'    => 'required|min:3',
            'email'   => 'required|email',
            'phone'   => 'required|min:10',
            'address' => 'required|min:10',
            'payment' => 'required',
            'terms'   => 'accepted',
        ]);

        $cart = session()->get('cart', []);
        if (empty($cart)) {
            return redirect()->route('cart.index');
        }

        DB::beginTransaction();
        try {
            $orderNumber = 'PK-' . date('Ymd') . '-' . rand(1000, 9999);
            $totalAmount = 0;

            // Buat data Order
            $order = Order::create([
                'order_number'    => $orderNumber,
                'user_id'         => auth()->check() ? auth()->id() : null, 
                'customer_name'   => $request->name,
                'customer_email'  => $request->email,
                'customer_phone'  => $request->phone,
                'customer_address'=> $request->address,
                'payment_method'  => $request->payment,
                'total_amount'    => 0, 
                'status'          => 'pending',
                'shipping_method' => explode('|', $request->shipping_method)[0],
                'shipping_cost'   => $request->shipping_cost,
            ]);

            // Simpan item & hitung total
            foreach ($cart as $productId => $qty) {
                $product = Product::findOrFail($productId);
                
                if ($product->stock < $qty) {
                    throw new \Exception("Stok {$product->name} tidak mencukupi.");
                }

                $subtotal = $product->price * $qty;
                $totalAmount += $subtotal;

                OrderItem::create([
                    'order_id'   => $order->id,
                    'product_id' => $product->id,
                    'qty'        => $qty,
                    'price'      => $product->price,
		    'product_name_snapshot' => $product->name,
                    'price_snapshot'        => $product->price,
                ]);

                // Kurangi Stok
                $product->decrement('stock', $qty);
            }

                        // --- LOGIKA KUPON & ONGKIR ---
            
            // 1. Tambahkan Ongkir ke Total
            $totalAmount += $request->shipping_cost;

            // 2. Terapkan Diskon Kupon (Hanya memotong harga barang)
            if ($request->coupon === 'PARTKU10') {
                $discount = $totalAmount * 0.10;
                $totalAmount = $totalAmount - $discount;
            }

            // Update total amount di order
            $order->update(['total_amount' => $totalAmount]);

            DB::commit(); 

            // Catat Log
            ActivityLog::create([
                'user_id'     => auth()->check() ? auth()->id() : null, 
                'action'      => 'CHECKOUT',
                'description' => 'Melakukan pemesanan dengan No. Order ' . $orderNumber . ' (Email: ' . $request->email . ')', 
                'ip_address'  => request()->ip()
            ]);

            session()->forget('cart');
            return redirect()->route('order.success', $order->id);

        } catch (\Exception $e) {
            DB::rollBack(); 
            return back()->with('error', 'Gagal memproses pesanan: ' . $e->getMessage());
        }
    }

    // 3. Halaman Sukses / Invoice
    public function success($id)
    {
        $order = Order::with('items.product')->findOrFail($id);
        return view('order-sukses', compact('order'));
    }

    // 4. Halaman Form Lacak Pesanan
    public function trackForm()
    {
        return view('lacak-pesanan');
    }

    // 5. Proses Lacak Pesanan (Pakai Email & No Order)
    public function trackResult(Request $request)
    {
        $request->validate([
            'order_number' => 'required',
            'email' => 'required|email'
        ]);
        
        $order = Order::with('items.product')
            ->where('order_number', $request->order_number)
            ->where('customer_email', $request->email)
            ->first();

        if (!$order) {
            return back()->with('error', 'Nomor order atau Email tidak ditemukan. Silakan periksa kembali.');
        }

        return view('lacak-pesanan', compact('order'));
    }
}